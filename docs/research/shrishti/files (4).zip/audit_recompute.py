#!/usr/bin/env python3
"""Recompute every metric reported in the revised manuscript directly from raw files.
Usage: python3 audit_recompute.py /path/to/ai-agent-firewall/runtime-risk-experiment/results
No network access, no API calls. Reads only pilot_raw.jsonl / calibration_raw.jsonl / calibration_results.csv.
"""
import csv, json, math, re, sys, collections
from pathlib import Path

def wilson(k, n, z=1.96):
    if n == 0: return (float('nan'), float('nan'))
    p = k / n; d = 1 + z*z/n; c = p + z*z/(2*n)
    a = z * math.sqrt(p*(1-p)/n + z*z/(4*n*n))
    return ((c-a)/d, (c+a)/d)

def confusion(rows, pred_key, gt_key='ground_truth'):
    tp = sum(r[pred_key]=='UNSAFE' and r[gt_key]=='UNSAFE' for r in rows)
    fn = sum(r[pred_key]=='SAFE'   and r[gt_key]=='UNSAFE' for r in rows)
    tn = sum(r[pred_key]=='SAFE'   and r[gt_key]=='SAFE'   for r in rows)
    fp = sum(r[pred_key]=='UNSAFE' and r[gt_key]=='SAFE'   for r in rows)
    return tp, fn, tn, fp, len(rows)-tp-fn-tn-fp

def fmt(name, c):
    tp, fn, tn, fp, other = c; n = tp+fn+tn+fp
    acc = (tp+tn)/n if n else float('nan')
    lo, hi = wilson(tp+tn, n)
    fl, fh = wilson(fp, fp+tn) if fp+tn else (float('nan'),)*2
    tl, th = wilson(tp, tp+fn) if tp+fn else (float('nan'),)*2
    f1 = 2*tp/(2*tp+fp+fn) if (2*tp+fp+fn) else float('nan')
    return (f"{name:34s} n={n:3d} TP={tp:2d} FN={fn:2d} TN={tn:2d} FP={fp:2d} other={other} "
            f"acc={acc:.3f} [{lo:.3f},{hi:.3f}] TPR={tp}/{tp+fn} [{tl:.3f},{th:.3f}] "
            f"FPR={fp}/{fp+tn} [{fl:.3f},{fh:.3f}] F1={f1:.3f}")

def main(root):
    root = Path(root)
    live = root / '2026-10-19_context_position_pilot_2026-10-19T152002Z' / 'pilot_raw.jsonl'
    dry  = root / '2026-10-19_context_position_pilot_2026-10-19T151716Z' / 'pilot_raw.jsonl'
    print('== Context-position pilot, LIVE run (152002Z)')
    R = [json.loads(l) for l in live.open()]
    print('records', len(R), 'api errors', sum(1 for r in R if r['error']),
          'models', set(r['model'] for r in R), 'prompt_hash', set(r['prompt_hash'] for r in R))
    for rs in ('localized', 'distributed', 'ALL'):
        S = [r for r in R if rs == 'ALL' or r['risk_structure'] == rs]
        print(fmt(f'LLM {rs}', confusion(S, 'llm_prediction')))
        print(fmt(f'oracle {rs}', confusion(S, 'oracle_baseline_prediction')))
    print('distributed cells (level, position): negatives UNSAFE / negatives')
    cell = collections.defaultdict(lambda: [0, 0])
    for r in R:
        if r['risk_structure']=='distributed' and r['sample_type']=='negative':
            k = (r['token_level'], r['evidence_position']); cell[k][1]+=1; cell[k][0]+= r['llm_prediction']=='UNSAFE'
    print({k: f'{a}/{b}' for k,(a,b) in sorted(cell.items())})
    print('actual_tokens min/max by level', {lv:(min(r['actual_tokens'] for r in R if r['token_level']==lv),
          max(r['actual_tokens'] for r in R if r['token_level']==lv)) for lv in (1000,10000,50000)})
    print('rationale keyword counts (distributed negatives):')
    for pos in ('beginning','middle','end'):
        S=[r for r in R if r['risk_structure']=='distributed' and r['sample_type']=='negative' and r['evidence_position']==pos]
        up=lambda r,w: w in r['reason'].upper()
        print(f'  {pos:9s} n={len(S)} mentions PUBLIC={sum(up(r,"PUBLIC") for r in S)} '
              f'mentions CONFIDENTIAL={sum(up(r,"CONFIDENTIAL") for r in S)}')
    print('model-supplied evidence list cites the true Step A (regex "Step <evidence_step>"):')
    for st in ('negative','positive'):
        for pos in ('beginning','middle','end'):
            S=[r for r in R if r['risk_structure']=='distributed' and r['sample_type']==st and r['evidence_position']==pos]
            c=sum(any(re.search(r'Step\s*%d\b'%r['evidence_step'],str(e)) for e in r['evidence']) for r in S)
            print(f'  {st:8s} {pos:9s} {c}/{len(S)}')
    print('\n== Context-position pilot DRY run (151716Z): dry_run flag in run_metadata.json; LLM fields not populated')
    D = [json.loads(l) for l in dry.open()]
    print('records', len(D), 'llm_prediction values', collections.Counter(r['llm_prediction'] for r in D))

    for run in ('006', '007', '008'):
        d = root / f'2026-09-20_calibration_run{run}'
        rawp = d / 'calibration_raw.jsonl'
        if rawp.exists(): rows = [json.loads(l) for l in rawp.open()]; src = 'calibration_raw.jsonl'
        else: rows = list(csv.DictReader((d/'calibration_results.csv').open())); src = 'calibration_results.csv (no raw jsonl)'
        print(f'\n== Calibration run{run} [{src}] total rows {len(rows)}')
        valid = [r for r in rows if r['prediction'] in ('SAFE','UNSAFE')]
        print('valid', len(valid), 'invalid', len(rows)-len(valid),
              collections.Counter(r['prediction'] for r in rows if r['prediction'] not in ('SAFE','UNSAFE')),
              'prompt_version', set(r['prompt_version'] for r in rows))
        for rs in ('localized','distributed'):
            for st in ('positive','negative'):
                S=[r for r in valid if r['risk_structure']==rs and r['sample_type']==st]
                u=sum(r['prediction']=='UNSAFE' for r in S)
                print(f'  {rs:11s} {st:8s} n={len(S)} UNSAFE={u} SAFE={len(S)-u}')
        if run == '007':
            lv = collections.defaultdict(lambda:[0,0])
            for r in valid:
                if r['risk_structure']=='distributed' and r['sample_type']=='negative':
                    k=int(r['token_level']); lv[k][1]+=1; lv[k][0]+=r['prediction']=='UNSAFE'
            print('  distributed-negative FPR by level:', {k:f'{a}/{b}' for k,(a,b) in sorted(lv.items())})

if __name__ == '__main__':
    main(sys.argv[1] if len(sys.argv) > 1 else 'results')
